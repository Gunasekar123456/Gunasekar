def leaprnot(year):
  if(year%4==0 or (year%4==0 and year%100!=0)):
    print(f"{year} is a leap year")
  else:
    print("{} is not a leap year".format(year))

y = int(input("Enter the year :"))
leaprnot(y)